/**
 * wrangler-config — public API
 *
 * Install deps:
 *   npm install zod smol-toml jsonc-parser
 */

// Schema & types
export * from "./schema.js";

// Parser (read / discover / validate)
export {
  findWranglerConfig,
  inferFormat,
  parseRaw,
  parseWranglerConfig,
  parseWranglerConfigDir,
  WranglerConfigReader,
  WranglerConfigError,
  type ConfigFormat,
  type DiscoveredConfig,
  type ParseResult,
} from "./parser.js";

// Updater (surgical in-place edits)
export {
  WranglerConfigUpdater,
  WranglerUpdateError,
  updateWranglerConfig,
  previewWranglerUpdate,
  type UpdateOperation,
  type UpdateResult,
  type ConfigPath,
} from "./updater.js";
