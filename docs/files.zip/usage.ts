/**
 * examples/usage.ts
 *
 * Demonstrates the full API surface of the wrangler-config module.
 */

import {
  // Parser
  parseWranglerConfig,
  parseWranglerConfigDir,
  WranglerConfigReader,
  findWranglerConfig,

  // Updater
  WranglerConfigUpdater,
  updateWranglerConfig,
  previewWranglerUpdate,

  // Schema (for custom validation)
  WranglerConfigSchema,
  KVNamespaceSchema,
} from "./src";

// ─────────────────────────────────────────────────────────────────────────────
// 1. Auto-discover and read a wrangler config
// ─────────────────────────────────────────────────────────────────────────────

// Auto-detect wrangler.jsonc / wrangler.json / wrangler.toml in cwd
const result = parseWranglerConfigDir("./my-worker");

// Pretty-print a summary
const reader = new WranglerConfigReader(result);
console.log(reader.summary());

// Access typed fields
console.log("Worker name:", reader.name);
console.log("Compat date:", reader.compatibilityDate);
console.log("KV namespaces:", reader.kvNamespaces);
console.log("Crons:", reader.crons);

// Merged env (top-level merged with production overrides)
const prodConfig = reader.mergedEnv("production");
console.log("Prod vars:", prodConfig.vars);

// ─────────────────────────────────────────────────────────────────────────────
// 2. Parse a specific file
// ─────────────────────────────────────────────────────────────────────────────

const parsed = parseWranglerConfig("./wrangler.jsonc");
console.log(parsed.config.name);       // string | undefined
console.log(parsed.config.d1_databases); // D1Database[] | undefined

// ─────────────────────────────────────────────────────────────────────────────
// 3. Surgical updates — JSONC (comment-preserving)
// ─────────────────────────────────────────────────────────────────────────────

const updater = new WranglerConfigUpdater("./wrangler.jsonc");

// Single field update
updater.setCompatibilityDate("2026-02-18");

// Batch update (single file write)
updater.update([
  { path: "name", value: "my-renamed-worker" },
  { path: "compatibility_date", value: "2026-02-18" },
  { path: ["vars", "API_ENDPOINT"], value: "https://api.example.com" },
  { path: ["observability", "enabled"], value: true },
]);

// Deep nested — e.g. update an env-specific var
updater.update([
  { path: ["env", "production", "vars", "API_KEY"], value: "prod-secret-xyz" },
]);

// Append a KV namespace (non-destructive)
updater.addKVNamespace("MY_CACHE", "kv-namespace-id-here", "preview-id-optional");

// Append a D1 database
updater.addD1Database("DB", "my-db", "d1-database-id");

// Append an R2 bucket
updater.addR2Bucket("ASSETS", "my-assets-bucket");

// Delete a key
updater.update({ path: ["vars", "DEPRECATED_KEY"], value: undefined });

// Add cron triggers
updater.setCrons(["0 * * * *", "0 0 * * *"]);

// ─────────────────────────────────────────────────────────────────────────────
// 4. Surgical updates — TOML
// ─────────────────────────────────────────────────────────────────────────────

const tomlUpdater = new WranglerConfigUpdater("./wrangler.toml", "toml");
tomlUpdater.setName("my-worker-v2");
tomlUpdater.setCompatibilityDate("2026-02-18");
tomlUpdater.update([
  { path: ["triggers", "crons"], value: ["*/5 * * * *"] },
  { path: ["kv_namespaces"], value: [
    { binding: "CACHE", id: "abc123" },
    { binding: "SESSIONS", id: "def456" },
  ]},
]);

// ─────────────────────────────────────────────────────────────────────────────
// 5. Preview changes without writing to disk
// ─────────────────────────────────────────────────────────────────────────────

const { before, after, changed } = previewWranglerUpdate("./wrangler.jsonc", [
  { path: "name", value: "preview-check-worker" },
]);

if (changed) {
  console.log("=== BEFORE ===");
  console.log(before);
  console.log("=== AFTER ===");
  console.log(after);
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. Functional one-liners
// ─────────────────────────────────────────────────────────────────────────────

const updated = updateWranglerConfig("./wrangler.jsonc", [
  { path: "compatibility_date", value: "2026-02-18" },
  { path: ["observability", "head_sampling_rate"], value: 0.1 },
]);
console.log("Updated config:", updated.name);

// ─────────────────────────────────────────────────────────────────────────────
// 7. Direct Zod schema usage (ad-hoc validation)
// ─────────────────────────────────────────────────────────────────────────────

const raw = {
  name: "test-worker",
  compatibility_date: "2026-01-01",
  kv_namespaces: [{ binding: "KV", id: "abc" }],
};

const validated = WranglerConfigSchema.parse(raw);
console.log(validated.kv_namespaces?.[0].binding); // "KV"

// Validate a single binding schema
const kv = KVNamespaceSchema.safeParse({ binding: "KV", id: "abc123" });
if (kv.success) console.log("KV valid:", kv.data);

// ─────────────────────────────────────────────────────────────────────────────
// 8. Discover without reading
// ─────────────────────────────────────────────────────────────────────────────

const found = findWranglerConfig("./my-worker-dir");
if (found) {
  console.log(`Found: ${found.filePath} (${found.format})`);
}
